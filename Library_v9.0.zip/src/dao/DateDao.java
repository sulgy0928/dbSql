package dao;

import java.util.ArrayList;



public interface DateDao {

	
	
}
