package dao;

public class AreaDaoImpl implements AreaDao{

}
