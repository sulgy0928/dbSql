package dao;

import java.util.ArrayList;

import vo.LikeBookVO;

public interface LikeBookDao {

	ArrayList<LikeBookVO> selectLikeBook();
	

	
}
