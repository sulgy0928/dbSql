package dao;

public interface AreaDao {

}
