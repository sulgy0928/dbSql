package service;

public interface LibraryService {

	
	void bookrecom();
	//사서가 콕! 찍어주는 책
	
	//공지사항 글 내용 보기
	void noticeView();

	
}