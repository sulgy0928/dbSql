package vo;

public class RentalVO {
	private String userID;
	private String bookNumber;
	private String rentalDate;
	private String returnDueDate;
	private String returnDate;
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getBookNumber() {
		return bookNumber;
	}
	public void setBookNumber(String bookNumber) {
		this.bookNumber = bookNumber;
	}
	public String getRentalDate() {
		return rentalDate;
	}
	public void setRentalDate(String rentalDate) {
		this.rentalDate = rentalDate;
	}
	public String getReturnDueDate() {
		return returnDueDate;
	}
	public void setReturnDueDate(String returnDueDate) {
		this.returnDueDate = returnDueDate;
	}
	public String getReturnDate() {
		return returnDate;
	}
	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}
	

	
}
